load("config.js");

function execute() {
  return Response.success([
    {
      title: "Danh sach truyen",
      input: REPO_URL + "/stories",
      script: "booklist.js"
    }
  ]);
}
