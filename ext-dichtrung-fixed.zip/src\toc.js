load("config.js");

function execute(url) {
  var branchName = parseBranchName(url);
  var chapters = fetchChaptersFromToc(branchName);

  if (!chapters || !chapters.length) {
    chapters = fetchChaptersFromDirectory(branchName);
  }

  if (!chapters || !chapters.length) {
    return Response.error("Cannot fetch chapter list");
  }

  chapters.sort(compareChapterItems);
  return Response.success(stripRuntimeFields(chapters));
}

function fetchChaptersFromToc(branchName) {
  var tocUrl = buildRawUrl(["Output", branchName, "toc.json"]);
  var json = requestJson(tocUrl);

  if (!json || !json.length) {
    return null;
  }

  var chapters = [];
  for (var i = 0; i < json.length; i++) {
    var chapter = json[i];
    if (!chapter || !chapter.relative_path) {
      continue;
    }

    chapters.push({
      order: chapter.chapter_number || i + 1,
      name: chapter.title || chapterTitleFromFilename(chapter.relative_path),
      url: chapterUrl(branchName, chapter.relative_path),
      host: RAW_BASE_URL
    });
  }

  return chapters;
}

function fetchChaptersFromDirectory(branchName) {
  var apiUrl = buildApiContentsUrl(["Output", branchName, "output"]);
  var files = requestJson(apiUrl);

  if (!files || !files.length) {
    return null;
  }

  var chapters = [];
  for (var i = 0; i < files.length; i++) {
    var item = files[i];
    if (!item || item.type !== "file" || !/\.md$/i.test(item.name)) {
      continue;
    }

    chapters.push({
      order: chapterNumberFromName(item.name),
      name: chapterTitleFromFilename(item.name),
      url: buildRawUrl(["Output", branchName, "output", item.name]),
      host: RAW_BASE_URL
    });
  }

  return chapters;
}

function stripRuntimeFields(chapters) {
  var cleaned = [];

  for (var i = 0; i < chapters.length; i++) {
    cleaned.push({
      name: chapters[i].name,
      url: chapters[i].url,
      host: chapters[i].host
    });
  }

  return cleaned;
}
