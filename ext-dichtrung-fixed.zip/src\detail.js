load("config.js");

function execute(url) {
  var progressUrl = buildRawUrl(["project_progress.json"]);
  var json = requestJson(progressUrl);
  var branchName = parseBranchName(url);

  if (!json || !json.milestones) {
    return Response.error("Cannot fetch project_progress.json");
  }

  var milestone = null;
  for (var i = 0; i < json.milestones.length; i++) {
    if (json.milestones[i] && json.milestones[i].branch === branchName) {
      milestone = json.milestones[i];
      break;
    }
  }

  if (!milestone) {
    return Response.error("Novel not found");
  }

  var readmeText = requestText(
    buildRawUrl(["Output", branchName, "README.md"]),
    "text/plain"
  );
  var readme = parseReadmeMetadata(readmeText) || {};

  return Response.success({
    name: readme.name || milestone.title,
    cover: COVER_URL,
    host: REPO_URL,
    author: readme.author || branchToAuthor(branchName),
    description:
      readme.summary ||
      ("Trang thai: " +
        milestone.status +
        "\nTien do: " +
        milestone.completed_chapters +
        "/" +
        milestone.total_chapters +
        " chuong"),
    detail:
      readme.context ||
      ("Trang thai: " +
        milestone.status +
        "\nTien do: " +
        milestone.completed_chapters +
        "/" +
        milestone.total_chapters +
        " chuong"),
    ongoing: milestone.status !== "COMPLETED",
    genres: [{ title: "Dich thuat" }, { title: "GitHub raw CDN" }]
  });
}
