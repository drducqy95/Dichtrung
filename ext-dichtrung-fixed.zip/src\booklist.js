load("config.js");

function execute(url, page) {
  var progressUrl = buildRawUrl(["project_progress.json"]);
  var json = requestJson(progressUrl);

  if (!json || !json.milestones) {
    return Response.error("Cannot fetch project_progress.json");
  }

  var books = [];
  for (var i = 0; i < json.milestones.length; i++) {
    var milestone = json.milestones[i];
    if (!milestone || !milestone.branch || !milestone.output_dir) {
      continue;
    }

    books.push({
      name: milestone.title,
      link: buildBookUrl(milestone.branch),
      cover: COVER_URL,
      description:
        "Tien do: " +
        milestone.completed_chapters +
        "/" +
        milestone.total_chapters +
        " chuong",
      host: REPO_URL
    });
  }

  books.sort(function (left, right) {
    var leftName = String(left.name || "");
    var rightName = String(right.name || "");
    if (leftName < rightName) {
      return -1;
    }
    if (leftName > rightName) {
      return 1;
    }
    return 0;
  });

  return Response.success(books);
}
