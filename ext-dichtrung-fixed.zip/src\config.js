var REPO_OWNER = "drducqy95";
var REPO_NAME = "Dichtrung";
var REPO_BRANCH = "main";

var RAW_BASE_URL =
  "https://raw.githubusercontent.com/" +
  REPO_OWNER +
  "/" +
  REPO_NAME +
  "/" +
  REPO_BRANCH;
var API_BASE_URL =
  "https://api.github.com/repos/" + REPO_OWNER + "/" + REPO_NAME;

var REPO_URL = "https://github.com/" + REPO_OWNER + "/" + REPO_NAME;
var BOOK_PATH_PREFIX = "/story/";
var COVER_URL = "https://github.com/" + REPO_OWNER + ".png";
var GITHUB_TOKEN = "";

function getHeaders(accept) {
  var headers = {
    "User-Agent": "vbook-dichtrung-extension"
  };

  if (accept) {
    headers.Accept = accept;
  }

  if (GITHUB_TOKEN) {
    headers.Authorization = "Bearer " + GITHUB_TOKEN;
  }

  return headers;
}

function encodePath(parts) {
  var list = parts;
  if (typeof parts === "string") {
    list = parts.split("/");
  }

  var encoded = [];
  for (var i = 0; i < list.length; i++) {
    if (list[i] === null || list[i] === undefined || list[i] === "") {
      continue;
    }
    encoded.push(encodeURIComponent(String(list[i])));
  }

  return encoded.join("/");
}

function buildRawUrl(parts) {
  return RAW_BASE_URL + "/" + encodePath(parts);
}

function buildApiContentsUrl(parts) {
  return API_BASE_URL + "/contents/" + encodePath(parts);
}

function requestText(url, accept) {
  try {
    var response = Http.get(url).headers(getHeaders(accept)).string();
    return response || null;
  } catch (error) {
    return null;
  }
}

function requestJson(url) {
  var text = requestText(url, "application/vnd.github+json");
  if (!text) {
    return null;
  }

  try {
    return JSON.parse(text);
  } catch (error) {
    return null;
  }
}

function decodeValue(value) {
  if (value === null || value === undefined) {
    return "";
  }

  try {
    return decodeURIComponent(String(value));
  } catch (error) {
    return String(value);
  }
}

function branchToAuthor(branchName) {
  if (!branchName || branchName.indexOf("_") === -1) {
    return "Khuyet danh";
  }

  var parts = branchName.split("_");
  return parts[parts.length - 1].replace(/_/g, " ");
}

function chapterUrl(branchName, relativePath) {
  var parts = ["Output", branchName];
  var relativeParts = String(relativePath || "").split("/");
  for (var i = 0; i < relativeParts.length; i++) {
    if (relativeParts[i]) {
      parts.push(relativeParts[i]);
    }
  }
  return buildRawUrl(parts);
}

function buildBookUrl(branchName) {
  return REPO_URL + BOOK_PATH_PREFIX + encodeURIComponent(branchName);
}

function parseBranchName(input) {
  var value = decodeValue(input);
  if (!value) {
    return "";
  }

  var marker = REPO_URL + BOOK_PATH_PREFIX;
  if (value.indexOf(marker) === 0) {
    return decodeValue(value.substring(marker.length));
  }

  var githubStoryMatch = value.match(/\/story\/([^?#]+)/);
  if (githubStoryMatch && githubStoryMatch[1]) {
    return decodeValue(githubStoryMatch[1]);
  }

  return value;
}

function normalizeLineBreaks(text) {
  return String(text || "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
}

function parseReadmeMetadata(text) {
  if (!text) {
    return null;
  }

  var lines = normalizeLineBreaks(text).split("\n");
  var fields = [];

  for (var i = 0; i < lines.length; i++) {
    var line = String(lines[i] || "").trim();
    if (!line) {
      continue;
    }

    if (line.charAt(0) === "#") {
      continue;
    }

    if (
      line.indexOf("Branch ") === 0 ||
      line.indexOf("Branch n") === 0 ||
      line.indexOf("Quy ") === 0 ||
      line.indexOf("Ebook:") === 0 ||
      line.indexOf("Converter DB:") === 0
    ) {
      break;
    }

    var separatorIndex = line.indexOf(":");
    if (separatorIndex === -1) {
      continue;
    }

    fields.push({
      key: line.substring(0, separatorIndex).trim(),
      value: line.substring(separatorIndex + 1).trim().replace(/^`+|`+$/g, "")
    });
  }

  if (!fields.length) {
    return null;
  }

  return {
    name: fields[0] ? fields[0].value : "",
    author: fields[1] ? fields[1].value : "",
    context: fields[2] ? fields[2].value : "",
    summary: fields[3] ? fields[3].value : ""
  };
}

function chapterTitleFromFilename(fileName) {
  var name = String(fileName || "").replace(/\.md$/i, "");
  return name.replace(/_/g, " ");
}

function chapterNumberFromName(name) {
  var match = String(name || "").match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 999999;
}

function compareChapterItems(left, right) {
  var leftOrder = left.order;
  var rightOrder = right.order;

  if (
    typeof leftOrder === "number" &&
    typeof rightOrder === "number" &&
    leftOrder !== rightOrder
  ) {
    return leftOrder - rightOrder;
  }

  var leftNumber = chapterNumberFromName(left.name || left.title);
  var rightNumber = chapterNumberFromName(right.name || right.title);

  if (leftNumber !== rightNumber) {
    return leftNumber - rightNumber;
  }

  var leftName = String(left.name || left.title || "");
  var rightName = String(right.name || right.title || "");

  if (leftName < rightName) {
    return -1;
  }
  if (leftName > rightName) {
    return 1;
  }
  return 0;
}

function escapeHtml(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
