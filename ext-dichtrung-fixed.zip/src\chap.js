load("config.js");

function execute(url) {
  var content = requestText(url, "text/plain");
  if (!content || content.indexOf("404: Not Found") === 0) {
    return Response.error("Cannot fetch chapter content");
  }

  return Response.success(renderMarkdown(content));
}

function renderMarkdown(markdown) {
  var lines = String(markdown || "").replace(/\r\n/g, "\n").split("\n");
  var html = [];

  for (var i = 0; i < lines.length; i++) {
    var trimmed = lines[i].trim();

    if (!trimmed) {
      continue;
    }

    if (/^#{1,6}\s+/.test(trimmed)) {
      html.push(
        "<p><b>" + escapeHtml(trimmed.replace(/^#{1,6}\s+/, "")) + "</b></p>"
      );
      continue;
    }

    if (/^[-*]\s+/.test(trimmed)) {
      html.push(
        "<p>&bull; " + formatInline(trimmed.replace(/^[-*]\s+/, "")) + "</p>"
      );
      continue;
    }

    html.push("<p>" + formatInline(trimmed) + "</p>");
  }

  return html.join("");
}

function formatInline(text) {
  var safe = escapeHtml(text);
  safe = safe.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
  safe = safe.replace(/\*(.+?)\*/g, "<i>$1</i>");
  safe = safe.replace(/`([^`]+)`/g, "<code>$1</code>");
  return safe;
}
