load("config.js");

function execute(url) {
    let bookUrl = normalizeBookUrl(url);
    let doc = fetchMirrorDoc(bookUrl);
    let chapterEls = doc.select("#list-chapterAll dd a");
    let data = [];

    for (let i = 0; i < chapterEls.size(); i++) {
        let chapterEl = chapterEls.get(i);
        let href = absoluteHref(chapterEl);
        if (!/\/book\/\d+\/\d+\.html$/i.test(href)) {
            continue;
        }

        data.push({
            name: cleanText(chapterEl.text()),
            url: href,
            host: BASE_URL
        });
    }

    return Response.success(data);
}
