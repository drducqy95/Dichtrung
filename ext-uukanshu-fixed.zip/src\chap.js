load("config.js");

function execute(url) {
    let doc = fetchMirrorDoc(normalizeChapterUrl(url));
    doc.select(".readcotent script").remove();
    doc.select(".readcotent .ad_content").remove();
    doc.select(".readcotent iframe").remove();

    let content = doc.select(".readcotent").html();
    content = String(content || "")
        .replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/https?:\/\/[^<>\s]+/gi, "")
        .replace(/UU看書/gi, "")
        .replace(/\s*<br>\s*/gi, "<br>")
        .trim();

    return Response.success(content);
}
