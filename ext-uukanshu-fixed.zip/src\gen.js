load("config.js");

function execute(url, page) {
    let targetUrl = normalizeSiteUrl(page || url);
    let doc = fetchMirrorDoc(targetUrl);
    let items = doc.select(".bookbox");
    let data = [];

    for (let i = 0; i < items.size(); i++) {
        let item = items.get(i);
        let linkEl = item.select("h4.bookname a").first();
        if (!linkEl) {
            continue;
        }

        let link = absoluteHref(linkEl);
        let author = item.select(".author").size() > 0 ? stripLabel(item.select(".author").get(0).text(), "作者：") : "";
        let words = item.select(".author").size() > 1 ? stripLabel(item.select(".author").get(1).text(), "字數：") : "";
        let intro = summaryText(item.select(".update").first());
        let description = [];

        if (author) {
            description.push("作者: " + author);
        }

        if (words) {
            description.push(words + "字");
        }

        if (intro) {
            description.push(intro);
        }

        data.push({
            name: cleanText(linkEl.text()),
            link: link,
            cover: coverFromBookId(extractBookId(link)),
            description: description.join(" | "),
            host: BASE_URL
        });
    }

    let nextLink = doc.select(".pages a.next").first();
    let next = nextLink ? absoluteHref(nextLink) : null;
    return Response.success(data, next);
}
