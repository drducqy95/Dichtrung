let BASE_URL = "https://uukanshu.cc";
let PROXY_BASE_URL = "https://r.jina.ai/";
let PROXY_HEADERS = {
    "x-respond-with": "html",
    "x-cache-tolerance": "300",
    "x-timeout": "15"
};

function normalizeSiteUrl(url) {
    if (!url) {
        return BASE_URL;
    }

    if (/^https?:\/\//i.test(url)) {
        return url.replace(/^https?:\/\/(?:www\.)?uukanshu\.cc/i, BASE_URL);
    }

    if (url.startsWith("/")) {
        return BASE_URL + url;
    }

    return BASE_URL + "/" + url.replace(/^\/+/, "");
}

function normalizeMirrorTarget(url) {
    return normalizeSiteUrl(url).replace(/^https?:\/\/(?:www\.)?uukanshu\.cc/i, "http://uukanshu.cc");
}

function fetchMirrorDoc(url) {
    return fetch(PROXY_BASE_URL + normalizeMirrorTarget(url), {
        headers: PROXY_HEADERS
    }).html();
}

function fetchMirrorText(url) {
    return fetch(PROXY_BASE_URL + normalizeMirrorTarget(url), {
        headers: PROXY_HEADERS
    }).text();
}

function cleanText(text) {
    return String(text || "")
        .replace(/\u00a0/g, " ")
        .replace(/[\t\r\n]+/g, " ")
        .replace(/\s{2,}/g, " ")
        .trim();
}

function stripLabel(text, label) {
    text = cleanText(text);
    if (label && text.indexOf(label) === 0) {
        return cleanText(text.slice(label.length));
    }
    return text;
}

function metaContent(doc, property) {
    let value = doc.select('meta[property="' + property + '"]').attr("content");
    if (!value) {
        value = doc.select('meta[name="' + property + '"]').attr("content");
    }
    return cleanText(value);
}

function extractBookId(url) {
    let match = normalizeSiteUrl(url).match(/\/book\/(\d+)(?:\/|$)/);
    return match ? match[1] : "";
}

function normalizeBookUrl(url) {
    let normalized = normalizeSiteUrl(url);
    let match = normalized.match(/https?:\/\/(?:www\.)?uukanshu\.cc\/book\/(\d+)(?:\/\d+\.html)?\/?$/i);
    return match ? BASE_URL + "/book/" + match[1] + "/" : normalized;
}

function normalizeChapterUrl(url) {
    return normalizeSiteUrl(url);
}

function coverFromBookId(bookId) {
    if (!bookId) {
        return "";
    }
    let folder = Math.floor(parseInt(bookId, 10) / 1000);
    return "https://image.uukanshu.cc/" + folder + "/" + bookId + "/" + bookId + "s.jpg";
}

function absoluteHref(element) {
    return normalizeSiteUrl(element ? element.attr("href") : "");
}

function summaryText(element) {
    if (!element) {
        return "";
    }
    element.select("span.noshow").remove();
    return stripLabel(element.text(), "簡介：");
}
