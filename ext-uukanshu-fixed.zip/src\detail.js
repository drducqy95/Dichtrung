load("config.js");

function execute(url) {
    let bookUrl = normalizeBookUrl(url);
    let doc = fetchMirrorDoc(bookUrl);
    let name = metaContent(doc, "og:title") || cleanText(doc.select("h1.booktitle").text());
    let author = metaContent(doc, "og:novel:author");
    let category = metaContent(doc, "og:novel:category");
    let status = metaContent(doc, "og:novel:status");
    let latest = metaContent(doc, "og:novel:latest_chapter_name");
    let updatedAt = metaContent(doc, "og:novel:update_time");
    let description = cleanText(doc.select(".bookintro").text()) || metaContent(doc, "og:description");
    let cover = metaContent(doc, "og:image") || coverFromBookId(extractBookId(bookUrl));
    let wordCount = doc.select(".booktag .blue").size() > 0 ? cleanText(doc.select(".booktag .blue").get(0).text()) : "";
    let detail = [];
    let genreLink = doc.select('.breadcrumb a[href*="/class_"]').last();

    if (category) {
        detail.push(category);
    }

    if (wordCount) {
        detail.push(wordCount);
    }

    if (latest) {
        detail.push("Moi nhat: " + latest);
    }

    if (updatedAt) {
        detail.push("Cap nhat: " + updatedAt);
    }

    let result = {
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detail.join(" | "),
        ongoing: status !== "完結" && status !== "完本",
        host: BASE_URL,
        url: bookUrl
    };

    if (genreLink) {
        result.genres = [{
            title: category || cleanText(genreLink.text()),
            input: absoluteHref(genreLink),
            script: "gen.js"
        }];
    }

    return Response.success(result);
}
