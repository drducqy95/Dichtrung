function execute() {
    return Response.success([
        { title: "玄幻奇幻", input: "https://uukanshu.cc/class_1_1.html", script: "gen.js" },
        { title: "武俠仙俠", input: "https://uukanshu.cc/class_2_1.html", script: "gen.js" },
        { title: "現代都市", input: "https://uukanshu.cc/class_3_1.html", script: "gen.js" },
        { title: "歷史軍事", input: "https://uukanshu.cc/class_4_1.html", script: "gen.js" },
        { title: "科幻小說", input: "https://uukanshu.cc/class_5_1.html", script: "gen.js" },
        { title: "遊戲競技", input: "https://uukanshu.cc/class_6_1.html", script: "gen.js" },
        { title: "恐怖靈異", input: "https://uukanshu.cc/class_7_1.html", script: "gen.js" },
        { title: "言情小說", input: "https://uukanshu.cc/class_8_1.html", script: "gen.js" },
        { title: "動漫同人", input: "https://uukanshu.cc/class_9_1.html", script: "gen.js" },
        { title: "其他類型", input: "https://uukanshu.cc/class_10_1.html", script: "gen.js" },
        { title: "總排行榜", input: "https://uukanshu.cc/top/allvisit_1.html", script: "gen.js" },
        { title: "全本小說", input: "https://uukanshu.cc/quanben/", script: "gen.js" }
    ]);
}
