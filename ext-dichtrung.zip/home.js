load("config.js");

function execute(url) {
    let sourceUrl = BASE_URL + "/contents/project_progress.json";
    let res = Http.get(sourceUrl).headers(getHeaders()).string();
    if (!res) return Response.error("Cannot fetch project progress");

    let json = JSON.parse(res);
    let books = [];
    if (json && json.milestones) {
        for (let i = 0; i < json.milestones.length; i++) {
            let m = json.milestones[i];
            if (m.status !== "PENDING" && m.id !== "M8") {
                books.push({
                    name: m.title,
                    link: m.branch,
                    cover: "https://raw.githubusercontent.com/drducqy95/Dichtrung/main/icon.png",
                    description: `Tiến độ: ${m.completed_chapters}/${m.total_chapters} chương`,
                    host: BASE_URL
                });
            }
        }
    }
    return Response.success(books);
}
