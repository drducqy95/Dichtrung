const BASE_URL = "https://api.github.com/repos/drducqy95/Dichtrung";
const GITHUB_TOKEN = "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";

function getHeaders() {
    return {
        "Authorization": "Bearer " + GITHUB_TOKEN,
        "Accept": "application/vnd.github.v3.raw"
    };
}
