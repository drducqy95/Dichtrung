load("config.js");

function execute(url) {
    let res = Http.get(url).headers(getHeaders()).string();
    if (!res) return Response.error("Cannot fetch chapter content");

    let paragraphs = res.split(/\r?\n/).filter(function (line) {
        return line.trim() !== "";
    });

    let htmlContent = paragraphs.map(function (p) {
        let trimmed = p.trim();
        if (trimmed.startsWith("#")) {
            return "<b>" + trimmed.replace(/#/g, '').trim() + "</b>";
        }
        return "<p>" + trimmed + "</p>";
    }).join("");

    return Response.success(htmlContent);
}
