load("config.js");

function execute(url) {
    let branchName = decodeURIComponent(url);
    let tocUrl = BASE_URL + "/contents/Output/" + encodeURIComponent(branchName) + "/toc.json";
    let res = Http.get(tocUrl).headers(getHeaders()).string();
    if (!res) return Response.error("Cannot fetch toc.json");

    let json = JSON.parse(res);
    let chapters = [];
    let hostStr = BASE_URL + "/contents/";

    for (let i = 0; i < json.length; i++) {
        let ch = json[i];
        let fileParts = ch.relative_path.split("/");
        let encodedPath = fileParts.map(p => encodeURIComponent(p)).join("/");

        chapters.push({
            name: ch.title,
            url: hostStr + "Output/" + encodeURIComponent(branchName) + "/" + encodedPath,
            host: hostStr
        });
    }
    return Response.success(chapters);
}
