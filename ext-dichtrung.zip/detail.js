load("config.js");

function execute(url) {
    let rootUrl = BASE_URL + "/contents/project_progress.json";
    let res = Http.get(rootUrl).headers(getHeaders()).string();
    if (!res) return Response.error("Cannot fetch data");

    let json = JSON.parse(res);
    let branchName = decodeURIComponent(url);

    let m = null;
    for (let i = 0; i < json.milestones.length; i++) {
        if (json.milestones[i].branch === branchName) {
            m = json.milestones[i];
            break;
        }
    }

    if (!m) return Response.error("Novel not found");

    let authorName = "Khuyết danh";
    if (m.branch && m.branch.indexOf("_") > -1) {
        let parts = m.branch.split("_");
        authorName = parts[parts.length - 1];
    }

    return Response.success({
        name: m.title,
        cover: "https://raw.githubusercontent.com/drducqy95/Dichtrung/main/icon.png",
        host: BASE_URL,
        author: authorName,
        description: `Tình trạng: ${m.status}\nTiến độ: ${m.completed_chapters}/${m.total_chapters}`,
        detail: url,
        ongoing: m.status === "IN_PROGRESS",
        genres: [{ title: "Dịch thuật" }]
    });
}
